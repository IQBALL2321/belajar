# Belajar Cepat (kerangka)

Aplikasi Android (Kotlin) untuk belajar mandiri: tombol melayang -> foto soal latihan/buku -> OCR on-device (ML Kit) -> penjelasan langkah demi langkah via Claude API.

## Cara menjalankan
1. Buka folder ini di Android Studio (Koala atau lebih baru), tunggu Gradle sync.
2. Jalankan di perangkat/emulator (minSdk 26).
3. Di aplikasi: isi API key, beri izin overlay, aktifkan tombol melayang.

## Catatan penting
- API key disimpan lokal hanya untuk prototipe. Untuk dirilis, panggil Claude lewat backend milikmu sendiri.
- Untuk latihan, try out, dan memahami materi. Jangan dipakai saat ujian yang melarang bantuan.

## Ide pengembangan
- Riwayat soal (Room), kuis ulang dari soal yang salah, mode "beri petunjuk saja" tanpa jawaban akhir,
  crop gambar sebelum OCR, dukungan rumus matematika.
