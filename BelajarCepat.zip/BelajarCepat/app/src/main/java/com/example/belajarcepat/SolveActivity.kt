package com.example.belajarcepat

import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.launch
import java.io.File

class SolveActivity : AppCompatActivity() {

    private lateinit var ocrText: EditText
    private lateinit var result: TextView
    private lateinit var explainBtn: Button
    private var photoUri: Uri? = null

    private val takePicture =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok) photoUri?.let { runOcr(it) }
        }

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            uri?.let { runOcr(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        col.addView(Button(this).apply {
            text = "Ambil foto soal"
            setOnClickListener {
                val dir = File(cacheDir, "photos").apply { mkdirs() }
                val f = File(dir, "soal_${System.currentTimeMillis()}.jpg")
                photoUri = FileProvider.getUriForFile(
                    this@SolveActivity, "$packageName.fileprovider", f
                )
                takePicture.launch(photoUri!!)
            }
        })
        col.addView(Button(this).apply {
            text = "Pilih dari galeri"
            setOnClickListener {
                pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }
        })

        ocrText = EditText(this).apply {
            hint = "Teks hasil OCR muncul di sini. Boleh diedit kalau ada salah baca."
            minLines = 4
        }
        col.addView(ocrText, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        explainBtn = Button(this).apply {
            text = "Jelaskan langkah demi langkah"
            setOnClickListener { explain() }
        }
        col.addView(explainBtn)

        result = TextView(this).apply { textSize = 15f; setTextIsSelectable(true) }
        col.addView(result)

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun runOcr(uri: Uri) {
        result.text = "Membaca teks..."
        val image = InputImage.fromFilePath(this, uri)
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .process(image)
            .addOnSuccessListener {
                ocrText.setText(it.text)
                result.text = if (it.text.isBlank()) "Teks tidak terbaca, coba foto lebih jelas." else ""
            }
            .addOnFailureListener { result.text = "OCR gagal: ${it.message}" }
    }

    private fun explain() {
        val key = Prefs.apiKey(this)
        val q = ocrText.text.toString().trim()
        if (key.isEmpty()) { result.text = "Isi API key di layar utama dulu."; return }
        if (q.isEmpty()) { result.text = "Belum ada teks soal."; return }

        explainBtn.isEnabled = false
        result.text = "Menyusun penjelasan..."
        lifecycleScope.launch {
            result.text = try {
                ClaudeClient.explain(key, q)
            } catch (e: Exception) {
                "Gagal: ${e.message}"
            }
            explainBtn.isEnabled = true
        }
    }
}
