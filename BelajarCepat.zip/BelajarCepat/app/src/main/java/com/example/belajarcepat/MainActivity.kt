package com.example.belajarcepat

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var keyInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Belajar Cepat\nFoto soal latihan → OCR → penjelasan langkah demi langkah."
            textSize = 16f
        })

        keyInput = EditText(this).apply {
            hint = "Anthropic API key (sk-ant-...)"
            setText(Prefs.apiKey(this@MainActivity))
        }
        root.addView(keyInput, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        root.addView(Button(this).apply {
            text = "Simpan API key"
            setOnClickListener {
                Prefs.saveApiKey(this@MainActivity, keyInput.text.toString().trim())
                toast("Tersimpan")
            }
        })

        root.addView(Button(this).apply {
            text = "1. Izinkan tampil di atas aplikasi lain"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        })

        root.addView(Button(this).apply {
            text = "2. Aktifkan tombol melayang"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    toast("Berikan izin overlay dulu"); return@setOnClickListener
                }
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                ContextCompat.startForegroundService(
                    this@MainActivity, Intent(this@MainActivity, FloatingService::class.java)
                )
            }
        })

        root.addView(Button(this).apply {
            text = "Matikan tombol melayang"
            setOnClickListener { stopService(Intent(this@MainActivity, FloatingService::class.java)) }
        })

        root.addView(Button(this).apply {
            text = "Buka pemindai soal langsung"
            setOnClickListener { startActivity(Intent(this@MainActivity, SolveActivity::class.java)) }
        })

        setContentView(root)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

object Prefs {
    private const val FILE = "settings"
    private const val KEY = "api_key"
    // Catatan: untuk produksi, jangan simpan API key di perangkat. Pakai backend proxy.
    fun apiKey(c: Context): String =
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY, "") ?: ""
    fun saveApiKey(c: Context, k: String) =
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY, k).apply()
}
