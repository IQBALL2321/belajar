package com.example.belajarcepat

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object ClaudeClient {
    private val http = OkHttpClient.Builder()
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private const val SYSTEM = """Kamu adalah tutor yang sabar. Pengguna memberi teks hasil OCR dari soal latihan 
atau buku pelajaran (mungkin ada salah baca). Jelaskan konsep yang dibutuhkan, lalu selesaikan 
langkah demi langkah dengan bahasa Indonesia yang sederhana, dan tutup dengan jawaban akhir serta 
satu tips agar pengguna bisa mengerjakan soal serupa sendiri. Jika teks OCR tidak jelas, sebutkan asumsimu."""

    suspend fun explain(apiKey: String, questionText: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("model", "claude-sonnet-5-5")
            put("max_tokens", 1500)
            put("system", SYSTEM)
            put("messages", JSONArray().put(
                JSONObject().put("role", "user").put("content", questionText)
            ))
        }.toString().toRequestBody("application/json".toMediaType())

        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .post(body)
            .build()

        http.newCall(req).execute().use { res ->
            val txt = res.body?.string().orEmpty()
            if (!res.isSuccessful) error("API ${res.code}: $txt")
            val content = JSONObject(txt).getJSONArray("content")
            buildString {
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    if (b.getString("type") == "text") append(b.getString("text"))
                }
            }
        }
    }
}
