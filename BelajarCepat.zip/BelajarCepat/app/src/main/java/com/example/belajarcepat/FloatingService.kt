package com.example.belajarcepat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.abs

/** Tombol melayang yang bisa digeser. Ketuk untuk membuka pemindai soal latihan. */
class FloatingService : Service() {

    private lateinit var wm: WindowManager
    private var bubble: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addBubble()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("floating", "Tombol melayang", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, "floating")
            .setContentTitle("Belajar Cepat aktif")
            .setContentText("Ketuk tombol melayang untuk memindai soal latihan")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
    }

    private fun addBubble() {
        val size = (56 * resources.displayMetrics.density).toInt()
        val view = TextView(this).apply {
            text = "📷"
            textSize = 24f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#CC1565C0"))
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24; y = 300
        }

        var startX = 0; var startY = 0
        var touchX = 0f; var touchY = 0f
        view.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y; touchX = e.rawX; touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (e.rawX - touchX).toInt()
                    lp.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP -> {
                    if (abs(e.rawX - touchX) < 10 && abs(e.rawY - touchY) < 10) {
                        startActivity(
                            Intent(this, SolveActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            }
            true
        }
        wm.addView(view, lp)
        bubble = view
    }

    override fun onDestroy() {
        bubble?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
